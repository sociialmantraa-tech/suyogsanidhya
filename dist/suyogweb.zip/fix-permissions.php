<?php
// Auto permission repair tool for GoDaddy Shared Hosting cPanel
header('Content-Type: text/html; charset=utf-8');

function fixPerms($dir) {
    $count = 0;
    $items = @scandir($dir);
    if (!$items) return 0;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $fullPath = $dir . '/' . $item;
        if (is_dir($fullPath)) {
            @chmod($fullPath, 0755);
            $count += 1 + fixPerms($fullPath);
        } else {
            @chmod($fullPath, 0644);
            $count++;
        }
    }
    return $count;
}

$root = __DIR__;
@chmod($root, 0755);
$total = fixPerms($root);

echo "<div style='font-family:sans-serif; max-w:600px; margin:50px auto; padding:30px; border-radius:16px; background:#F0FDF4; border:2px solid #22C55E; color:#15803D;'>";
echo "<h1 style='margin-top:0;'>✔ GoDaddy File Permissions Fixed!</h1>";
echo "<p style='font-size:16px;'>Successfully reset permissions for <strong>{$total}</strong> files & directories to <strong>0755 / 0644</strong>.</p>";
echo "<p style='font-size:16px;'>Your website CSS, JavaScript, and images are now 100% accessible.</p>";
echo "<p style='margin-bottom:0;'><a href='/' style='display:inline-block; background:#166D74; color:white; padding:12px 24px; text-decoration:none; border-radius:50px; font-weight:bold;'>Open Suyog Saanidhya Homepage &rarr;</a></p>";
echo "</div>";
?>